-- Item
CREATE TABLE Item (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) UNIQUE,
    price FLOAT,
    weight FLOAT
);

-- Purchase
CREATE TABLE Purchase (
    id SERIAL PRIMARY KEY,
    customer_name VARCHAR(255) UNIQUE,
    price FLOAT,
    weight FLOAT,
    delivery_date TIMESTAMP
);

-- Address
CREATE TABLE Address (
    id SERIAL PRIMARY KEY,
    address VARCHAR(255),
    city VARCHAR(100),
    zipcode VARCHAR(20)
);

-- Trip
CREATE TABLE Trip (
    id SERIAL PRIMARY KEY,
    departure TIMESTAMP,
    state VARCHAR(20),
    purchase_id INT REFERENCES Purchase(id)
);

-- Truck
CREATE TABLE Truck (
    id SERIAL PRIMARY KEY,
    plate_number VARCHAR(20),
    max_weight_capacity FLOAT,
    work_days VARCHAR(20)
);

-- Purchase and Item (Many to Many)
CREATE TABLE Purchase_Item (
    purchase_id INT REFERENCES Purchase(id),
    item_id INT REFERENCES Item(id),
    PRIMARY KEY (purchase_id, item_id)
);

-- Purchase and Address (Many to Many)
CREATE TABLE Purchase_Address (
    purchase_id INT REFERENCES Purchase(id),
    address_id INT REFERENCES Address(id),
    PRIMARY KEY (purchase_id, address_id)
);

-- Trip and Truck (One to Many)
ALTER TABLE Trip ADD COLUMN truck_id INT REFERENCES Truck(id);
