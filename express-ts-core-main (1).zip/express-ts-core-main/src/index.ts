import express from "express"
import client, { connect } from "./db"
import { Trip } from "./types"

const app = express()

connect()

app.get("/items", async (req, res) => {
  // ejemplo de query macheando contra types Trip, quizas no usar jsonb_build_object y mapear manualmente 
  const { rows } = await client.query<Trip>(
    `SELECT 
      trip.*, 
      jsonb_build_object(
        'id', truck.id, 
        'plate_number', truck.plate_number, 
        'max_weight_capacity', truck.max_weight_capacity, 
        'work_days', truck.work_days
      ) as truck 
     FROM trip 
     INNER JOIN truck on trip.truck_id = truck.id`,
  )
  res.json(rows[0].truck)
})

app.listen(3000, () => {
  console.log("Server started on http://localhost:3000")
})
