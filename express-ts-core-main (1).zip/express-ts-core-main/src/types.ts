export type Item = {
  id: number
  name: string
  price: number
  weight: number
}

export type Truck = {
  id: number
  plate_number: string
  max_weight_capacity: number
  work_days: string
}

export type Trip = {
  id: number
  departure: Date
  state: string
  truck_id: number
  truck: Truck
}
